﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.L0 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.L1 = New System.Windows.Forms.Label()
        Me.L2 = New System.Windows.Forms.Label()
        Me.L3 = New System.Windows.Forms.Label()
        Me.L4 = New System.Windows.Forms.Label()
        Me.L5 = New System.Windows.Forms.Label()
        Me.L6 = New System.Windows.Forms.Label()
        Me.L7 = New System.Windows.Forms.Label()
        Me.L8 = New System.Windows.Forms.Label()
        Me.L9 = New System.Windows.Forms.Label()
        Me.C0 = New System.Windows.Forms.ComboBox()
        Me.C1 = New System.Windows.Forms.ComboBox()
        Me.C3 = New System.Windows.Forms.ComboBox()
        Me.C2 = New System.Windows.Forms.ComboBox()
        Me.C7 = New System.Windows.Forms.ComboBox()
        Me.C6 = New System.Windows.Forms.ComboBox()
        Me.C5 = New System.Windows.Forms.ComboBox()
        Me.C4 = New System.Windows.Forms.ComboBox()
        Me.C9 = New System.Windows.Forms.ComboBox()
        Me.C8 = New System.Windows.Forms.ComboBox()
        Me.TB1 = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.LST1 = New System.Windows.Forms.ListBox()
        Me.L11 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.LST2 = New System.Windows.Forms.ListBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.CB1 = New System.Windows.Forms.CheckBox()
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'Label2
        '
        Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label2.Font = New System.Drawing.Font("Courier New", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(12, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(712, 37)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "TAKEOFF QUEUE"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label3.Font = New System.Drawing.Font("Courier New", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(12, 46)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(712, 503)
        Me.Label3.TabIndex = 4
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label4.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(21, 55)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 20)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "POS"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label5.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(67, 55)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(138, 20)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "CALLSIGN"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label6.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(210, 55)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(125, 20)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "STATUS"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'L0
        '
        Me.L0.BackColor = System.Drawing.Color.White
        Me.L0.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.L0.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L0.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.L0.Location = New System.Drawing.Point(64, 87)
        Me.L0.Name = "L0"
        Me.L0.Size = New System.Drawing.Size(136, 26)
        Me.L0.TabIndex = 9
        Me.L0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label7.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(21, 87)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(45, 26)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "1"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label9.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(21, 125)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(45, 26)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "2"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label10.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(21, 163)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(45, 26)
        Me.Label10.TabIndex = 12
        Me.Label10.Text = "3"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label11.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(21, 201)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(45, 26)
        Me.Label11.TabIndex = 13
        Me.Label11.Text = "4"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label12.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(21, 239)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(45, 26)
        Me.Label12.TabIndex = 14
        Me.Label12.Text = "5"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label13
        '
        Me.Label13.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label13.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(21, 277)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(45, 26)
        Me.Label13.TabIndex = 15
        Me.Label13.Text = "6"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label14
        '
        Me.Label14.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label14.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(21, 315)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(45, 26)
        Me.Label14.TabIndex = 16
        Me.Label14.Text = "7"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label15
        '
        Me.Label15.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label15.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(21, 353)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(45, 26)
        Me.Label15.TabIndex = 17
        Me.Label15.Text = "8"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label16.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(21, 429)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(45, 26)
        Me.Label16.TabIndex = 19
        Me.Label16.Text = "10"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label17
        '
        Me.Label17.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label17.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(21, 391)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(45, 26)
        Me.Label17.TabIndex = 18
        Me.Label17.Text = "9"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'L1
        '
        Me.L1.BackColor = System.Drawing.Color.White
        Me.L1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.L1.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.L1.Location = New System.Drawing.Point(64, 125)
        Me.L1.Name = "L1"
        Me.L1.Size = New System.Drawing.Size(136, 26)
        Me.L1.TabIndex = 20
        Me.L1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'L2
        '
        Me.L2.BackColor = System.Drawing.Color.White
        Me.L2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.L2.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.L2.Location = New System.Drawing.Point(64, 163)
        Me.L2.Name = "L2"
        Me.L2.Size = New System.Drawing.Size(136, 26)
        Me.L2.TabIndex = 21
        Me.L2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'L3
        '
        Me.L3.BackColor = System.Drawing.Color.White
        Me.L3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.L3.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.L3.Location = New System.Drawing.Point(64, 201)
        Me.L3.Name = "L3"
        Me.L3.Size = New System.Drawing.Size(136, 26)
        Me.L3.TabIndex = 22
        Me.L3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'L4
        '
        Me.L4.BackColor = System.Drawing.Color.White
        Me.L4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.L4.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.L4.Location = New System.Drawing.Point(64, 239)
        Me.L4.Name = "L4"
        Me.L4.Size = New System.Drawing.Size(136, 26)
        Me.L4.TabIndex = 23
        Me.L4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'L5
        '
        Me.L5.BackColor = System.Drawing.Color.White
        Me.L5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.L5.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.L5.Location = New System.Drawing.Point(64, 277)
        Me.L5.Name = "L5"
        Me.L5.Size = New System.Drawing.Size(136, 26)
        Me.L5.TabIndex = 24
        Me.L5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'L6
        '
        Me.L6.BackColor = System.Drawing.Color.White
        Me.L6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.L6.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.L6.Location = New System.Drawing.Point(64, 315)
        Me.L6.Name = "L6"
        Me.L6.Size = New System.Drawing.Size(136, 26)
        Me.L6.TabIndex = 25
        Me.L6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'L7
        '
        Me.L7.BackColor = System.Drawing.Color.White
        Me.L7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.L7.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.L7.Location = New System.Drawing.Point(64, 353)
        Me.L7.Name = "L7"
        Me.L7.Size = New System.Drawing.Size(136, 26)
        Me.L7.TabIndex = 26
        Me.L7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'L8
        '
        Me.L8.BackColor = System.Drawing.Color.White
        Me.L8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.L8.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.L8.Location = New System.Drawing.Point(64, 391)
        Me.L8.Name = "L8"
        Me.L8.Size = New System.Drawing.Size(136, 26)
        Me.L8.TabIndex = 27
        Me.L8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'L9
        '
        Me.L9.BackColor = System.Drawing.Color.White
        Me.L9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.L9.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.L9.Location = New System.Drawing.Point(64, 429)
        Me.L9.Name = "L9"
        Me.L9.Size = New System.Drawing.Size(136, 26)
        Me.L9.TabIndex = 28
        Me.L9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'C0
        '
        Me.C0.BackColor = System.Drawing.Color.White
        Me.C0.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.C0.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C0.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.C0.FormattingEnabled = True
        Me.C0.Items.AddRange(New Object() {"TAXI", "LINEUP", "DEPART"})
        Me.C0.Location = New System.Drawing.Point(210, 87)
        Me.C0.Name = "C0"
        Me.C0.Size = New System.Drawing.Size(121, 26)
        Me.C0.TabIndex = 29
        '
        'C1
        '
        Me.C1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.C1.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.C1.FormattingEnabled = True
        Me.C1.Items.AddRange(New Object() {"TAXI", "LINEUP", "DEPART"})
        Me.C1.Location = New System.Drawing.Point(210, 125)
        Me.C1.Name = "C1"
        Me.C1.Size = New System.Drawing.Size(121, 26)
        Me.C1.TabIndex = 30
        '
        'C3
        '
        Me.C3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.C3.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.C3.FormattingEnabled = True
        Me.C3.Items.AddRange(New Object() {"TAXI", "LINEUP", "DEPART"})
        Me.C3.Location = New System.Drawing.Point(210, 201)
        Me.C3.Name = "C3"
        Me.C3.Size = New System.Drawing.Size(121, 26)
        Me.C3.TabIndex = 32
        '
        'C2
        '
        Me.C2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.C2.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.C2.FormattingEnabled = True
        Me.C2.Items.AddRange(New Object() {"TAXI", "LINEUP", "DEPART"})
        Me.C2.Location = New System.Drawing.Point(210, 163)
        Me.C2.Name = "C2"
        Me.C2.Size = New System.Drawing.Size(121, 26)
        Me.C2.TabIndex = 31
        '
        'C7
        '
        Me.C7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.C7.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.C7.FormattingEnabled = True
        Me.C7.Items.AddRange(New Object() {"TAXI", "LINEUP", "DEPART"})
        Me.C7.Location = New System.Drawing.Point(210, 353)
        Me.C7.Name = "C7"
        Me.C7.Size = New System.Drawing.Size(121, 26)
        Me.C7.TabIndex = 36
        '
        'C6
        '
        Me.C6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.C6.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.C6.FormattingEnabled = True
        Me.C6.Items.AddRange(New Object() {"TAXI", "LINEUP", "DEPART"})
        Me.C6.Location = New System.Drawing.Point(210, 315)
        Me.C6.Name = "C6"
        Me.C6.Size = New System.Drawing.Size(121, 26)
        Me.C6.TabIndex = 35
        '
        'C5
        '
        Me.C5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.C5.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.C5.FormattingEnabled = True
        Me.C5.Items.AddRange(New Object() {"TAXI", "LINEUP", "DEPART"})
        Me.C5.Location = New System.Drawing.Point(210, 277)
        Me.C5.Name = "C5"
        Me.C5.Size = New System.Drawing.Size(121, 26)
        Me.C5.TabIndex = 34
        '
        'C4
        '
        Me.C4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.C4.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.C4.FormattingEnabled = True
        Me.C4.Items.AddRange(New Object() {"TAXI", "LINEUP", "DEPART"})
        Me.C4.Location = New System.Drawing.Point(210, 239)
        Me.C4.Name = "C4"
        Me.C4.Size = New System.Drawing.Size(121, 26)
        Me.C4.TabIndex = 33
        '
        'C9
        '
        Me.C9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.C9.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.C9.FormattingEnabled = True
        Me.C9.Items.AddRange(New Object() {"TAXI", "LINEUP", "DEPART"})
        Me.C9.Location = New System.Drawing.Point(210, 429)
        Me.C9.Name = "C9"
        Me.C9.Size = New System.Drawing.Size(121, 26)
        Me.C9.TabIndex = 38
        '
        'C8
        '
        Me.C8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.C8.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.C8.FormattingEnabled = True
        Me.C8.Items.AddRange(New Object() {"TAXI", "LINEUP", "DEPART"})
        Me.C8.Location = New System.Drawing.Point(210, 391)
        Me.C8.Name = "C8"
        Me.C8.Size = New System.Drawing.Size(121, 26)
        Me.C8.TabIndex = 37
        '
        'TB1
        '
        Me.TB1.BackColor = System.Drawing.Color.White
        Me.TB1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TB1.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TB1.Location = New System.Drawing.Point(18, 467)
        Me.TB1.Name = "TB1"
        Me.TB1.Size = New System.Drawing.Size(125, 29)
        Me.TB1.TabIndex = 39
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.White
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(149, 467)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(182, 29)
        Me.Button2.TabIndex = 40
        Me.Button2.Text = "ADD TO QUEUE"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'LST1
        '
        Me.LST1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LST1.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LST1.FormattingEnabled = True
        Me.LST1.ItemHeight = 21
        Me.LST1.Location = New System.Drawing.Point(346, 178)
        Me.LST1.Name = "LST1"
        Me.LST1.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.LST1.Size = New System.Drawing.Size(121, 359)
        Me.LST1.TabIndex = 41
        '
        'L11
        '
        Me.L11.BackColor = System.Drawing.Color.White
        Me.L11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.L11.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.L11.Location = New System.Drawing.Point(623, 87)
        Me.L11.Name = "L11"
        Me.L11.Size = New System.Drawing.Size(89, 28)
        Me.L11.TabIndex = 42
        Me.L11.Text = "READY"
        Me.L11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(342, 55)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(370, 27)
        Me.Label1.TabIndex = 43
        Me.Label1.Text = "DEPARTURE SEPARATION"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label8.Font = New System.Drawing.Font("Courier New", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(341, 54)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(375, 65)
        Me.Label8.TabIndex = 44
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label18
        '
        Me.Label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label18.Font = New System.Drawing.Font("Courier New", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(341, 125)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(258, 418)
        Me.Label18.TabIndex = 45
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LST2
        '
        Me.LST2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LST2.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LST2.FormattingEnabled = True
        Me.LST2.ItemHeight = 21
        Me.LST2.Location = New System.Drawing.Point(472, 178)
        Me.LST2.Name = "LST2"
        Me.LST2.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.LST2.Size = New System.Drawing.Size(122, 359)
        Me.LST2.TabIndex = 46
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.White
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(18, 502)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(313, 41)
        Me.Button1.TabIndex = 47
        Me.Button1.Text = "RECALL LAST DEPARTURE"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label19
        '
        Me.Label19.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label19.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(351, 87)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(266, 28)
        Me.Label19.TabIndex = 48
        Me.Label19.Text = "TIME TO NEXT DEPARTURE"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label20
        '
        Me.Label20.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label20.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.White
        Me.Label20.Location = New System.Drawing.Point(344, 126)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(250, 49)
        Me.Label20.TabIndex = 49
        Me.Label20.Text = "DEPARTURE BOARD"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(605, 125)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(111, 337)
        Me.Button3.TabIndex = 50
        Me.Button3.Text = "V1.0.0"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(605, 468)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(111, 51)
        Me.Button4.TabIndex = 51
        Me.Button4.Text = "Q GUIDE"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Timer2
        '
        '
        'CB1
        '
        Me.CB1.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CB1.ForeColor = System.Drawing.Color.White
        Me.CB1.Location = New System.Drawing.Point(612, 521)
        Me.CB1.Name = "CB1"
        Me.CB1.Size = New System.Drawing.Size(100, 24)
        Me.CB1.TabIndex = 52
        Me.CB1.Text = "MUTE SFX"
        Me.CB1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CB1.UseVisualStyleBackColor = True
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(738, 561)
        Me.Controls.Add(Me.CB1)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.LST2)
        Me.Controls.Add(Me.LST1)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.L11)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TB1)
        Me.Controls.Add(Me.C9)
        Me.Controls.Add(Me.C8)
        Me.Controls.Add(Me.C7)
        Me.Controls.Add(Me.C6)
        Me.Controls.Add(Me.C5)
        Me.Controls.Add(Me.C4)
        Me.Controls.Add(Me.C3)
        Me.Controls.Add(Me.C2)
        Me.Controls.Add(Me.C1)
        Me.Controls.Add(Me.C0)
        Me.Controls.Add(Me.L9)
        Me.Controls.Add(Me.L8)
        Me.Controls.Add(Me.L7)
        Me.Controls.Add(Me.L6)
        Me.Controls.Add(Me.L5)
        Me.Controls.Add(Me.L4)
        Me.Controls.Add(Me.L3)
        Me.Controls.Add(Me.L2)
        Me.Controls.Add(Me.L1)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.L0)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label3)
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Main"
        Me.Text = "Dan's ATC24 Slot Manager Version 1.0.0"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents L0 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents L1 As Label
    Friend WithEvents L2 As Label
    Friend WithEvents L3 As Label
    Friend WithEvents L4 As Label
    Friend WithEvents L5 As Label
    Friend WithEvents L6 As Label
    Friend WithEvents L7 As Label
    Friend WithEvents L8 As Label
    Friend WithEvents L9 As Label
    Friend WithEvents C0 As ComboBox
    Friend WithEvents C1 As ComboBox
    Friend WithEvents C3 As ComboBox
    Friend WithEvents C2 As ComboBox
    Friend WithEvents C7 As ComboBox
    Friend WithEvents C6 As ComboBox
    Friend WithEvents C5 As ComboBox
    Friend WithEvents C4 As ComboBox
    Friend WithEvents C9 As ComboBox
    Friend WithEvents C8 As ComboBox
    Friend WithEvents TB1 As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents LST1 As ListBox
    Friend WithEvents L11 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents LST2 As ListBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Timer2 As Timer
    Friend WithEvents CB1 As CheckBox
    Friend WithEvents Timer3 As Timer
End Class
