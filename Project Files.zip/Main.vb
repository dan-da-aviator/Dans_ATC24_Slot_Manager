﻿Imports System.Data.SqlTypes
Imports System.Linq.Expressions
Imports Microsoft.VisualBasic.Logging

Public Class Main
    Dim countDown1 As Integer = 90
    Dim countDown2 As Integer = 0
    Dim colourSwitch As Boolean = False

    Dim callsign(9) As String
    Dim pos(9) As Integer

    Dim prevStatus As Integer

    Dim queueCount As Integer

    Dim prevCallsign As String
    Dim prevPos As Integer

    Dim add As Boolean

    Private Sub addToList()
        If LST1.Items.Count = 17 Then
            If LST2.Items.Count = 17 Then
                LST1.Items.Clear()
                LST2.Items.Clear()

                LST1.Items.Add(prevCallsign)
            Else
                LST2.Items.Add(prevCallsign)
            End If
        Else
            LST1.Items.Add(prevCallsign)
        End If

        L11.BackColor = Color.White

        countDown1 = 90
        L11.Text = "01:30"
        Timer1.Start()

        add = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TB1.Text <> "" And queueCount < 10 Then
            callsign(queueCount) = UCase(TB1.Text)
            queueCount = queueCount + 1

            runCallsign()

            TB1.Text = ""

            add = False
        End If
        Me.ActiveControl = Nothing
    End Sub

    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        queueCount = 0
        prevPos = 10
        add = False
    End Sub

    Private Sub runCallsign()
        If queueCount - 1 = 0 Then
            L0.Text = callsign(queueCount - 1)
            C0.SelectedIndex = 0
        ElseIf queueCount - 1 = 1 Then
            L1.Text = callsign(queueCount - 1)
            C1.SelectedIndex = 0
        ElseIf queueCount - 1 = 2 Then
            L2.Text = callsign(queueCount - 1)
            C2.SelectedIndex = 0
        ElseIf queueCount - 1 = 3 Then
            L3.Text = callsign(queueCount - 1)
            C3.SelectedIndex = 0
        ElseIf queueCount - 1 = 4 Then
            L4.Text = callsign(queueCount - 1)
            C4.SelectedIndex = 0
        ElseIf queueCount - 1 = 5 Then
            L5.Text = callsign(queueCount - 1)
            C5.SelectedIndex = 0
        ElseIf queueCount - 1 = 6 Then
            L6.Text = callsign(queueCount - 1)
            C6.SelectedIndex = 0
        ElseIf queueCount - 1 = 7 Then
            L7.Text = callsign(queueCount - 1)
            C7.SelectedIndex = 0
        ElseIf queueCount - 1 = 8 Then
            L8.Text = callsign(queueCount - 1)
            C8.SelectedIndex = 0
        ElseIf queueCount - 1 = 9 Then
            L9.Text = callsign(queueCount - 1)
            C9.SelectedIndex = 0
        End If
    End Sub

    Private Sub C0_SelectedIndexChanged(sender As Object, e As EventArgs) Handles C0.SelectedIndexChanged
        If L0.Text <> "" And queueCount > 0 Then

            If C0.SelectedIndex = 2 Then
                prevPos = 0
                prevCallsign = L0.Text

                moveUp(0)

                queueCount = queueCount - 1

                addToList()
            End If

        ElseIf L0.Text = "" Or queueCount <= 0 Then
            C0.SelectedIndex = -1
        End If
        Me.ActiveControl = Nothing
    End Sub
    Private Sub moveUp(index As Integer)
        Select Case index
            Case 0
                L0.Text = L1.Text
                L1.Text = L2.Text
                L2.Text = L3.Text
                L3.Text = L4.Text
                L4.Text = L5.Text
                L5.Text = L6.Text
                L6.Text = L7.Text
                L7.Text = L8.Text
                L8.Text = L9.Text

                C0.SelectedIndex = C1.SelectedIndex
                C1.SelectedIndex = C2.SelectedIndex
                C2.SelectedIndex = C3.SelectedIndex
                C3.SelectedIndex = C4.SelectedIndex
                C4.SelectedIndex = C5.SelectedIndex
                C5.SelectedIndex = C6.SelectedIndex
                C6.SelectedIndex = C7.SelectedIndex
                C7.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = C9.SelectedIndex
            Case 1
                L1.Text = L2.Text
                L2.Text = L3.Text
                L3.Text = L4.Text
                L4.Text = L5.Text
                L5.Text = L6.Text
                L6.Text = L7.Text
                L7.Text = L8.Text
                L8.Text = L9.Text

                C1.SelectedIndex = C2.SelectedIndex
                C2.SelectedIndex = C3.SelectedIndex
                C3.SelectedIndex = C4.SelectedIndex
                C4.SelectedIndex = C5.SelectedIndex
                C5.SelectedIndex = C6.SelectedIndex
                C6.SelectedIndex = C7.SelectedIndex
                C7.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = C9.SelectedIndex
            Case 2
                L2.Text = L3.Text
                L3.Text = L4.Text
                L4.Text = L5.Text
                L5.Text = L6.Text
                L6.Text = L7.Text
                L7.Text = L8.Text
                L8.Text = L9.Text

                C2.SelectedIndex = C3.SelectedIndex
                C3.SelectedIndex = C4.SelectedIndex
                C4.SelectedIndex = C5.SelectedIndex
                C5.SelectedIndex = C6.SelectedIndex
                C6.SelectedIndex = C7.SelectedIndex
                C7.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = C9.SelectedIndex
            Case 3
                L3.Text = L4.Text
                L4.Text = L5.Text
                L5.Text = L6.Text
                L6.Text = L7.Text
                L7.Text = L8.Text
                L8.Text = L9.Text

                C3.SelectedIndex = C4.SelectedIndex
                C4.SelectedIndex = C5.SelectedIndex
                C5.SelectedIndex = C6.SelectedIndex
                C6.SelectedIndex = C7.SelectedIndex
                C7.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = C9.SelectedIndex
            Case 4
                L4.Text = L5.Text
                L5.Text = L6.Text
                L6.Text = L7.Text
                L7.Text = L8.Text
                L8.Text = L9.Text

                C4.SelectedIndex = C5.SelectedIndex
                C5.SelectedIndex = C6.SelectedIndex
                C6.SelectedIndex = C7.SelectedIndex
                C7.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = C9.SelectedIndex
            Case 5
                L5.Text = L6.Text
                L6.Text = L7.Text
                L7.Text = L8.Text
                L8.Text = L9.Text

                C5.SelectedIndex = C6.SelectedIndex
                C6.SelectedIndex = C7.SelectedIndex
                C7.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = C9.SelectedIndex
            Case 6
                L6.Text = L7.Text
                L7.Text = L8.Text
                L8.Text = L9.Text

                C6.SelectedIndex = C7.SelectedIndex
                C7.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = C9.SelectedIndex
            Case 7
                L7.Text = L8.Text
                L8.Text = L9.Text

                C7.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = C9.SelectedIndex
            Case 8
                L8.Text = L9.Text

                C8.SelectedIndex = C9.SelectedIndex
        End Select
        L9.Text = ""
        C9.SelectedIndex = -1
    End Sub

    Private Sub C1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles C1.SelectedIndexChanged
        If L1.Text <> "" And queueCount > 1 Then

            If C1.SelectedIndex = 2 Then
                prevPos = 1
                prevCallsign = L1.Text

                moveUp(1)

                queueCount = queueCount - 1

                addToList()
            End If

        ElseIf L1.Text = "" Or queueCount <= 1 Then
            C1.SelectedIndex = -1
        End If
        Me.ActiveControl = Nothing
    End Sub

    Private Sub C2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles C2.SelectedIndexChanged
        If L2.Text <> "" And queueCount > 2 Then

            If C2.SelectedIndex = 2 Then
                prevPos = 2
                prevCallsign = L2.Text

                moveUp(2)

                queueCount = queueCount - 1

                addToList()
            End If

        ElseIf L2.Text = "" Or queueCount <= 2 Then
            C2.SelectedIndex = -1
        End If
        Me.ActiveControl = Nothing
    End Sub

    Private Sub C3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles C3.SelectedIndexChanged
        If L3.Text <> "" And queueCount > 3 Then

            If C3.SelectedIndex = 2 Then
                prevPos = 3
                prevCallsign = L3.Text

                moveUp(3)

                queueCount = queueCount - 1

                addToList()
            End If

        ElseIf L3.Text = "" Or queueCount <= 3 Then
            C3.SelectedIndex = -1
        End If
        Me.ActiveControl = Nothing
    End Sub

    Private Sub C4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles C4.SelectedIndexChanged
        If L4.Text <> "" And queueCount > 4 Then

            If C4.SelectedIndex = 2 Then
                prevPos = 4
                prevCallsign = L4.Text

                moveUp(4)

                queueCount = queueCount - 1

                addToList()
            End If

        ElseIf L4.Text = "" Or queueCount <= 4 Then
            C4.SelectedIndex = -1
        End If
        Me.ActiveControl = Nothing
    End Sub

    Private Sub C5_SelectedIndexChanged(sender As Object, e As EventArgs) Handles C5.SelectedIndexChanged
        If L5.Text <> "" And queueCount > 5 Then

            If C5.SelectedIndex = 2 Then
                prevPos = 5
                prevCallsign = L5.Text

                moveUp(5)

                queueCount = queueCount - 1

                addToList()
            End If

        ElseIf L5.Text = "" Or queueCount <= 5 Then
            C5.SelectedIndex = -1
        End If
        Me.ActiveControl = Nothing
    End Sub

    Private Sub C6_SelectedIndexChanged(sender As Object, e As EventArgs) Handles C6.SelectedIndexChanged
        If L6.Text <> "" And queueCount > 6 Then

            If C6.SelectedIndex = 2 Then
                prevPos = 6
                prevCallsign = L6.Text

                moveUp(6)

                queueCount = queueCount - 1

                addToList()
            End If

        ElseIf L6.Text = "" Or queueCount <= 6 Then
            C6.SelectedIndex = -1
        End If
        Me.ActiveControl = Nothing
    End Sub

    Private Sub C7_SelectedIndexChanged(sender As Object, e As EventArgs) Handles C7.SelectedIndexChanged
        If L7.Text <> "" And queueCount > 7 Then

            If C7.SelectedIndex = 2 Then
                prevPos = 7
                prevCallsign = L7.Text

                moveUp(7)

                queueCount = queueCount - 1

                addToList()
            End If

        ElseIf L7.Text = "" Or queueCount <= 7 Then
            C7.SelectedIndex = -1
        End If
        Me.ActiveControl = Nothing
    End Sub

    Private Sub C8_SelectedIndexChanged(sender As Object, e As EventArgs) Handles C8.SelectedIndexChanged
        If L8.Text <> "" And queueCount > 8 Then

            If C8.SelectedIndex = 2 Then
                prevPos = 8
                prevCallsign = L8.Text

                moveUp(8)

                queueCount = queueCount - 1

                addToList()
            End If

        ElseIf L8.Text = "" Or queueCount <= 8 Then
            C8.SelectedIndex = -1
        End If
        Me.ActiveControl = Nothing
    End Sub

    Private Sub C9_SelectedIndexChanged(sender As Object, e As EventArgs) Handles C9.SelectedIndexChanged
        If L9.Text <> "" And queueCount > 9 Then

            If C9.SelectedIndex = 2 Then
                prevPos = 9
                prevCallsign = L9.Text

                moveUp(9)

                queueCount = queueCount - 1

                addToList()
            End If

        ElseIf L9.Text = "" Or queueCount <= 9 Then
            C9.SelectedIndex = -1
        End If
        Me.ActiveControl = Nothing
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If add = True Then
            queueCount = queueCount + 1
            If prevPos = 0 Then
                L9.Text = L8.Text
                L8.Text = L7.Text
                L7.Text = L6.Text
                L6.Text = L5.Text
                L5.Text = L4.Text
                L4.Text = L3.Text
                L3.Text = L2.Text
                L2.Text = L1.Text
                L1.Text = L0.Text
                L0.Text = prevCallsign

                C9.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = C7.SelectedIndex
                C7.SelectedIndex = C6.SelectedIndex
                C6.SelectedIndex = C5.SelectedIndex
                C5.SelectedIndex = C4.SelectedIndex
                C4.SelectedIndex = C3.SelectedIndex
                C3.SelectedIndex = C2.SelectedIndex
                C2.SelectedIndex = C1.SelectedIndex
                C1.SelectedIndex = C0.SelectedIndex
                C0.SelectedIndex = prevStatus
            ElseIf prevPos = 1 Then
                L9.Text = L8.Text
                L8.Text = L7.Text
                L7.Text = L6.Text
                L6.Text = L5.Text
                L5.Text = L4.Text
                L4.Text = L3.Text
                L3.Text = L2.Text
                L2.Text = L1.Text
                L1.Text = prevCallsign

                C9.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = C7.SelectedIndex
                C7.SelectedIndex = C6.SelectedIndex
                C6.SelectedIndex = C5.SelectedIndex
                C5.SelectedIndex = C4.SelectedIndex
                C4.SelectedIndex = C3.SelectedIndex
                C3.SelectedIndex = C2.SelectedIndex
                C2.SelectedIndex = C1.SelectedIndex
                C1.SelectedIndex = prevStatus
            ElseIf prevPos = 2 Then
                L9.Text = L8.Text
                L8.Text = L7.Text
                L7.Text = L6.Text
                L6.Text = L5.Text
                L5.Text = L4.Text
                L4.Text = L3.Text
                L3.Text = L2.Text
                L2.Text = prevCallsign

                C9.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = C7.SelectedIndex
                C7.SelectedIndex = C6.SelectedIndex
                C6.SelectedIndex = C5.SelectedIndex
                C5.SelectedIndex = C4.SelectedIndex
                C4.SelectedIndex = C3.SelectedIndex
                C3.SelectedIndex = C2.SelectedIndex
                C2.SelectedIndex = prevStatus
            ElseIf prevPos = 3 Then
                L9.Text = L8.Text
                L8.Text = L7.Text
                L7.Text = L6.Text
                L6.Text = L5.Text
                L5.Text = L4.Text
                L4.Text = L3.Text
                L3.Text = prevCallsign

                C9.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = C7.SelectedIndex
                C7.SelectedIndex = C6.SelectedIndex
                C6.SelectedIndex = C5.SelectedIndex
                C5.SelectedIndex = C4.SelectedIndex
                C4.SelectedIndex = C3.SelectedIndex
                C3.SelectedIndex = prevStatus
            ElseIf prevPos = 4 Then
                L9.Text = L8.Text
                L8.Text = L7.Text
                L7.Text = L6.Text
                L6.Text = L5.Text
                L5.Text = L4.Text
                L4.Text = prevCallsign

                C9.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = C7.SelectedIndex
                C7.SelectedIndex = C6.SelectedIndex
                C6.SelectedIndex = C5.SelectedIndex
                C5.SelectedIndex = C4.SelectedIndex
                C4.SelectedIndex = prevStatus
            ElseIf prevPos = 5 Then
                L9.Text = L8.Text
                L8.Text = L7.Text
                L7.Text = L6.Text
                L6.Text = L5.Text
                L5.Text = prevCallsign

                C9.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = C7.SelectedIndex
                C7.SelectedIndex = C6.SelectedIndex
                C6.SelectedIndex = C5.SelectedIndex
                C5.SelectedIndex = prevStatus
            ElseIf prevPos = 6 Then
                L9.Text = L8.Text
                L8.Text = L7.Text
                L7.Text = L6.Text
                L6.Text = prevCallsign

                C9.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = C7.SelectedIndex
                C7.SelectedIndex = C6.SelectedIndex
                C6.SelectedIndex = prevStatus
            ElseIf prevPos = 7 Then
                L9.Text = L8.Text
                L8.Text = L7.Text
                L7.Text = prevCallsign

                C9.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = C7.SelectedIndex
                C7.SelectedIndex = prevStatus
            ElseIf prevPos = 8 Then
                L9.Text = L8.Text
                L8.Text = prevCallsign

                C9.SelectedIndex = C8.SelectedIndex
                C8.SelectedIndex = prevStatus
            ElseIf prevPos = 9 Then
                L9.Text = prevCallsign

                C9.SelectedIndex = prevStatus
            End If
            add = False
            If LST1.Items.Count = 17 Then
                LST2.Items.RemoveAt(LST2.Items.Count - 1)
            Else
                LST1.Items.RemoveAt(LST1.Items.Count - 1)
            End If
        End If
        Me.ActiveControl = Nothing
    End Sub

    Private Sub C0_Enter(sender As Object, e As EventArgs) Handles C0.Enter
        If L0.Text <> "" And queueCount > 0 Then
            prevStatus = C0.SelectedIndex
        Else
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub C1_Enter(sender As Object, e As EventArgs) Handles C1.Enter
        If L1.Text <> "" And queueCount > 1 Then
            prevStatus = C1.SelectedIndex
        Else
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub C2_Enter(sender As Object, e As EventArgs) Handles C2.Enter
        If L2.Text <> "" And queueCount > 2 Then
            prevStatus = C2.SelectedIndex
        Else
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub C3_Enter(sender As Object, e As EventArgs) Handles C3.Enter
        If L3.Text <> "" And queueCount > 3 Then
            prevStatus = C3.SelectedIndex
        Else
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub C4_Enter(sender As Object, e As EventArgs) Handles C4.Enter
        If L4.Text <> "" And queueCount > 4 Then
            prevStatus = C4.SelectedIndex
        Else
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub C5_Enter(sender As Object, e As EventArgs) Handles C5.Enter
        If L5.Text <> "" And queueCount > 5 Then
            prevStatus = C5.SelectedIndex
        Else
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub C6_Enter(sender As Object, e As EventArgs) Handles C6.Enter
        If L6.Text <> "" And queueCount > 6 Then
            prevStatus = C6.SelectedIndex
        Else
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub C7_Enter(sender As Object, e As EventArgs) Handles C7.Enter
        If L7.Text <> "" And queueCount > 7 Then
            prevStatus = C7.SelectedIndex
        Else
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub C8_Enter(sender As Object, e As EventArgs) Handles C8.Enter
        If L8.Text <> "" And queueCount > 8 Then
            prevStatus = C8.SelectedIndex
        Else
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub C9_Enter(sender As Object, e As EventArgs) Handles C9.Enter
        If L9.Text <> "" And queueCount > 9 Then
            prevStatus = C9.SelectedIndex
        Else
            Me.ActiveControl = Nothing
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        countDown1 -= 1

        If countDown1 <= 0 Then
            Timer1.Stop()
            L11.Text = "READY"

            L11.BackColor = Color.Red

            If CB1.Checked = False Then
                System.Media.SystemSounds.Exclamation.Play()
            End If

            countDown2 = 0
            Timer2.Interval = 1200
            Timer2.Start()
            Return
        End If
        L11.Text = TimeSpan.FromSeconds(countDown1).ToString("mm\:ss")
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        If CB1.Checked = False Then
            System.Media.SystemSounds.Exclamation.Play()
        End If

        If colourSwitch = False Then
            L11.BackColor = Color.Yellow
            colourSwitch = True
        Else
            L11.BackColor = Color.Red
            colourSwitch = False
        End If

        countDown2 += 1

        If countDown2 >= 3 Then
            L11.BackColor = Color.Yellow
            colourSwitch = False
            Timer2.Stop()
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        MsgBox("Dan's ATC24 Slot Manger is out!! You can find details on ALL features on the GitHub page. Make sure to read the instructions!")
        Me.ActiveControl = Nothing
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        MsgBox("To begin keeping track of what aircraft is in front of what, add the callsigns into the queue using the textbox and the 'ADD TO QUEUE' button. From there you can edit the 'status' which keeps track of what you've cleared the aircraft to do (eg. lineup). After deprting an aircraft, it is reccomended to seperate the departures by around 1 1/2 minutes for wake turblence/speed differences.")
        Me.ActiveControl = Nothing
    End Sub

    Private Sub TB1_Leave(sender As Object, e As EventArgs) Handles TB1.Leave
        TB1.Text = UCase(TB1.Text)
    End Sub
End Class